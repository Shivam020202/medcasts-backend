// Hostinger Node.js Web Apps entry point
// This is the main entry point for the application

// Load environment variables
require("dotenv").config();

// Load the compiled Express application
const app = require("./dist/server").default;
const { sequelize } = require("./dist/models");

const PORT = process.env.PORT || 3000;

// Start the server
app.listen(PORT, async () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📍 Environment: ${process.env.NODE_ENV || "development"}`);

  // Connect to database
  try {
    await sequelize.authenticate();
    console.log("✅ Database connected");
  } catch (error) {
    console.error("❌ Database connection failed:", error.message);
  }
});

module.exports = app;
